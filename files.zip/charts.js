const COL={accent:'#5fd4c4',accent2:'#f2b35c',good:'#6fcf97',warn:'#f2c94c',bad:'#eb5757',blue:'#6c9bf2',purple:'#b794f6',muted:'#9aa7c2',grid:'rgba(255,255,255,0.06)',text:'#eef1f7'};
Chart.defaults.font.family="'Inter', sans-serif";
Chart.defaults.color=COL.muted;
Chart.defaults.font.size=11.5;
const MESES=['Jan','Fev','Mar','Abr','Mai','Jun'];
const bG={grid:{color:COL.grid,drawBorder:false},ticks:{color:COL.muted}};
const charts={};
function mC(id,cfg){const el=document.getElementById(id);if(!el)return;if(charts[id]){charts[id].destroy();}charts[id]=new Chart(el,cfg);}
// meta line helper
function metaLine(val,label,color){return{type:'line',label:label||'Meta',data:[val,val,val,val,val,val],borderColor:color||COL.warn,borderDash:[6,4],borderWidth:1.5,pointRadius:0,fill:false};}

function renderVisaoGeral(){
  mC('chart-tickets-mes',{type:'bar',data:{labels:MESES,datasets:[
    {label:'WhatsApp',data:[7664,6949,8551,7512,6294,7792],backgroundColor:COL.accent,borderRadius:4},
    {label:'Telefone',data:[2045,1954,2434,2452,1954,2154],backgroundColor:COL.blue,borderRadius:4},
    {label:'E-mail',data:[270,259,220,404,612,1526],backgroundColor:COL.accent2,borderRadius:4},
    {label:'Interno',data:[951,795,839,340,252,554],backgroundColor:COL.purple,borderRadius:4},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{stacked:true,...bG,grid:{display:false}},y:{stacked:true,...bG}}}});

  mC('chart-canais',{type:'doughnut',data:{labels:['WhatsApp (44.762)','Telefone (12.993)','Interno (3.731)','E-mail (3.291)'],datasets:[{data:[44762,12993,3731,3291],backgroundColor:[COL.accent,COL.blue,COL.purple,COL.accent2],borderColor:'#161e2e',borderWidth:3}]},options:{responsive:true,maintainAspectRatio:false,cutout:'62%',plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:12,font:{size:11}}}}}});

  mC('chart-yoy-tickets',{type:'bar',data:{labels:MESES,datasets:[
    {label:'2025',data:[7203,7072,10523,12432,12562,12934],backgroundColor:'rgba(154,167,194,0.35)',borderRadius:4},
    {label:'2026',data:[10930,9957,12044,10708,9112,11926],backgroundColor:COL.accent,borderRadius:4},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG}}}});
}

function renderExperiencia(){
  mC('chart-satisfacao-yoy',{type:'line',data:{labels:MESES,datasets:[
    {label:'2025',data:[86,85,81,81,77,81],borderColor:'rgba(154,167,194,0.6)',backgroundColor:'transparent',tension:0.35,borderDash:[5,4]},
    {label:'2026',data:[84.6,85.4,84.4,81,81.4,76.5],borderColor:COL.bad,backgroundColor:'rgba(235,87,87,0.08)',tension:0.35,fill:true},
    {type:'line',label:'Meta (90%)',data:[90,90,90,90,90,90],borderColor:COL.warn,borderDash:[6,4],borderWidth:1.5,pointRadius:0,fill:false},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,min:65,max:95,ticks:{callback:v=>v+'%'}}}}});

  mC('chart-csat-tel-yoy',{type:'line',data:{labels:MESES,datasets:[
    {label:'2025',data:[72,76,57,82,68,55],borderColor:'rgba(154,167,194,0.6)',backgroundColor:'transparent',tension:0.35,borderDash:[5,4]},
    {label:'2026',data:[87.3,87.3,90.9,92.8,92.2,89.3],borderColor:COL.good,backgroundColor:'rgba(111,207,151,0.1)',tension:0.35,fill:true},
    {type:'line',label:'Meta (92%)',data:[92,92,92,92,92,92],borderColor:COL.warn,borderDash:[6,4],borderWidth:1.5,pointRadius:0,fill:false},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,min:45,max:100,ticks:{callback:v=>v+'%'}}}}});

  mC('chart-nps',{type:'bar',data:{labels:['Darwin','Atend.','A24h','Vidros','Sinistro','CR'],datasets:[
    {label:'Jun/26',data:[23,80,83,83,100,50],backgroundColor:COL.accent,borderRadius:4},
    {label:'Meta',data:[75,80,85,85,75,85],backgroundColor:'rgba(242,201,76,0.2)',borderRadius:4,borderWidth:1,borderColor:COL.warn},
  ]},options:{indexAxis:'y',responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,ticks:{callback:v=>v+'%'}},y:{...bG,grid:{display:false}}}}});
}

function renderEficiencia(){
  mC('chart-ns',{type:'line',data:{labels:MESES,datasets:[
    {label:'NS Geral',data:[64,75,79,80.9,71.8,84.1],borderColor:COL.accent,backgroundColor:'transparent',tension:0.3},
    {label:'NS CE',data:[59,72,77,78,66,83.8],borderColor:COL.blue,backgroundColor:'transparent',tension:0.3},
    {label:'NS SAC',data:[91,92,89,94,90,97.4],borderColor:COL.good,backgroundColor:'transparent',tension:0.3},
    {label:'NS Ouvidoria',data:[83,91,91,100,92,100],borderColor:COL.accent2,backgroundColor:'transparent',tension:0.3},
    {type:'line',label:'Meta Geral (80%)',data:[80,80,80,80,80,80],borderColor:'rgba(95,212,196,0.4)',borderDash:[6,4],borderWidth:1.2,pointRadius:0,fill:false},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:12,font:{size:11}}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,min:45,max:105,ticks:{callback:v=>v+'%'}}}}});

  mC('chart-tme-abandono',{type:'bar',data:{labels:MESES,datasets:[
    {type:'bar',label:'TME (s)',data:[83,50,43,38,59,39],backgroundColor:COL.purple,borderRadius:4,yAxisID:'y'},
    {type:'line',label:'% Abandono',data:[10.2,6.7,5.9,4.2,8.1,16.2],borderColor:COL.bad,backgroundColor:'transparent',tension:0.3,yAxisID:'y1'},
    {type:'line',label:'Meta Abandono (3%)',data:[3,3,3,3,3,3],borderColor:COL.warn,borderDash:[6,4],borderWidth:1.5,pointRadius:0,fill:false,yAxisID:'y1'},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,position:'left',title:{display:true,text:'TME (s)',color:COL.muted,font:{size:11}}},y1:{position:'right',grid:{display:false},ticks:{callback:v=>v+'%',color:COL.muted},title:{display:true,text:'% Abandono',color:COL.muted,font:{size:11}}}}}});

  // NS Canais Digitais Jun vs meta (barras comparativas)
  mC('chart-ns-digital',{type:'bar',data:{
    labels:['TMPR E-mail\n(85% ≤59min)','TTR E-mail\n(80% ≤45min)','TMPR Wpp\n(85% ≤7min)','TTR Wpp\n(80% ≤30min)'],
    datasets:[
      {label:'Jun/26',data:[15.6,69.7,84,97],backgroundColor:[COL.bad,COL.good,COL.accent,COL.good],borderRadius:4},
      {label:'Meta',data:[85,80,85,80],backgroundColor:'rgba(242,201,76,0.15)',borderRadius:4,borderWidth:1,borderColor:COL.warn},
    ]
  },options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,min:0,max:105,ticks:{callback:v=>v+'%'}}}}});
}

function renderTecnologia(){
  mC('chart-retencao-ia',{type:'bar',data:{labels:MESES,datasets:[
    {label:'% Retenção Kat.IA',data:[35,33,35.9,39,40.75,50.96],backgroundColor:MESES.map((_,i)=>i===5?COL.good:COL.accent),borderRadius:4},
    {type:'line',label:'Meta (50%)',data:[50,50,50,50,50,50],borderColor:COL.warn,borderDash:[6,4],borderWidth:1.5,pointRadius:0,fill:false},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,min:25,max:60,ticks:{callback:v=>v+'%'}}}}});

  mC('chart-copilot',{type:'bar',data:{labels:MESES,datasets:[
    {label:'Tickets c/ assistência automática',data:[683,7574,9247,8372,7291,7732],backgroundColor:COL.blue,borderRadius:4},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{...bG,grid:{display:false}},y:{...bG}}}});
}

function renderQualidade(){
  mC('chart-qa',{type:'line',data:{labels:MESES,datasets:[
    {label:'Score de Precisão',data:[93,91.5,92.3,93,76.84,90.87],borderColor:COL.accent,backgroundColor:'rgba(95,212,196,0.08)',fill:true,tension:0.3},
    {label:'IQI',data:[96,93.2,96.6,92.3,90.98,89.86],borderColor:COL.accent2,backgroundColor:'transparent',tension:0.3},
    {type:'line',label:'Meta Precisão (90%)',data:[90,90,90,90,90,90],borderColor:COL.warn,borderDash:[6,4],borderWidth:1.5,pointRadius:0,fill:false},
    {type:'line',label:'Meta IQI (93%)',data:[93,93,93,93,93,93],borderColor:'rgba(183,148,246,0.6)',borderDash:[4,4],borderWidth:1.2,pointRadius:0,fill:false},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{...bG,grid:{display:false}},y:{...bG,min:65,max:100,ticks:{callback:v=>v+'%'}}}}});

  mC('chart-qa-volume',{type:'bar',data:{labels:MESES,datasets:[
    {label:'Conversas avaliadas',data:[5235,4576,5582,5077,2443,3493],backgroundColor:MESES.map((_,i)=>i===4?COL.bad:COL.purple),borderRadius:4},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{...bG,grid:{display:false}},y:{...bG}}}});
}

function renderPessoas(){
  mC('chart-pessoas',{type:'bar',data:{labels:MESES,datasets:[
    {label:'Agentes Darwin',data:[5,5,5,6,6,6],backgroundColor:COL.accent,borderRadius:4},
    {label:'Agentes Pluris',data:[6,9,8,7,7,0],backgroundColor:COL.accent2,borderRadius:4},
    {label:'Agentes B4B',data:[0,0,0,0,0,8],backgroundColor:COL.blue,borderRadius:4},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}},scales:{x:{stacked:true,...bG,grid:{display:false}},y:{stacked:true,...bG}}}});
}

const renderers={'visao-geral':renderVisaoGeral,'experiencia':renderExperiencia,'eficiencia':renderEficiencia,'tecnologia':renderTecnologia,'qualidade':renderQualidade,'pessoas':renderPessoas};
window.renderChartsFor=function(tab){const fn=renderers[tab];if(fn)setTimeout(fn,30);};
