document.getElementById('sections-root').innerHTML = `

<!-- ===== 1. VISÃO GERAL ===== -->
<section id="visao-geral" class="active">
  <div class="section-head">
    <div class="section-tag">Bloco 01 — O tamanho e o ritmo da operação</div>
    <div class="section-title">Visão Geral da Operação</div>
    <p class="section-desc">Junho foi o mês de maior volume do semestre (11.926 tickets, +30,9% vs maio) e concentrou três mudanças simultâneas: integração WhatsApp→URA, consolidação do status de sinistro na IA e início do B4B. Os ganhos estruturais são claros — a satisfação sentiu o impacto da transição.</p>
  </div>
  <div class="alert-bar">⚠ Carteira Auto caiu de 41.243 (mai) para <strong>35.679 (jun) — queda de 5.564 veículos (-13,5%)</strong>. Verificar com área comercial: sazonalidade, ajuste de base ou perda real de carteira?</div>
  <div class="grid grid-4">
    <div class="card kpi">
      <div class="label">Carteira Auto (Jun)</div>
      <div class="value">35.679</div>
      <div class="delta down">▼ vs 41.243 mai (-13,5%)</div>
      <div class="note">Média Jan–Jun: 39.584 veículos</div>
    </div>
    <div class="card kpi">
      <div class="label">Total de Tickets (Jun)</div>
      <div class="value">11.926</div>
      <div class="delta up">▲ +30,9% vs mai — maior do semestre</div>
      <div class="note">Acumulado Jan–Jun: 64.677 (+3,1% vs 2025)</div>
    </div>
    <div class="card kpi">
      <div class="label">% Atendimento Digital (Jun)</div>
      <div class="value">77,3%</div>
      <div class="delta up">▲ vs 75,8% mai</div>
      <span class="meta-badge meta-miss">● Meta: 80%</span>
    </div>
    <div class="card kpi">
      <div class="label">TTR Geral (Jun)</div>
      <div class="value">47 min</div>
      <div class="delta down">▲ vs 38 min mai</div>
      <div class="note">Acumulado Jan–Jun: 42 min</div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Volume de Tickets por Mês — 2026</div>
      <div class="chart-box"><canvas id="chart-tickets-mes"></canvas></div>
    </div>
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Distribuição por Canal — Acumulado Jan–Jun</div>
      <div class="chart-box"><canvas id="chart-canais"></canvas></div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Tickets YoY — 2025 vs 2026 (Jan–Jun)</div>
      <div class="chart-box"><canvas id="chart-yoy-tickets"></canvas></div>
    </div>
    <div class="read-panel" style="display:flex;flex-direction:column;justify-content:center;">
      <div class="ptitle"><span class="badge info"><span class="dot"></span>LEITURA EXECUTIVA</span></div>
      <p>O salto de volume em junho (+2.814 tickets vs maio) está em parte relacionado à <strong>integração do WhatsApp na URA</strong>, que pode ter gerado novos registros de contato, e ao crescimento expressivo do canal e-mail (<strong>612 → 1.526, +149%</strong>) — possivelmente por notificações automáticas do novo fluxo de URA.</p>
      <p>O acumulado Jan–Jun supera 2025 em +3,1%, mesmo com a oscilação da carteira Auto. A leitura é de operação em crescimento sustentado, com mudança relevante de composição de canais.</p>
    </div>
  </div>
</section>

<!-- ===== 2. EXPERIÊNCIA ===== -->
<section id="experiencia">
  <div class="section-head">
    <div class="section-tag">Bloco 02 — Como o cliente está percebendo o atendimento</div>
    <div class="section-title">Experiência do Cliente</div>
    <p class="section-desc">Junho apresenta queda generalizada de satisfação em todos os canais digitais — o sinal de maior atenção do mês. Causa identificável: novo fluxo WhatsApp→URA gerou fricção de experiência. Requer monitoramento para confirmar normalização em julho/agosto.</p>
  </div>
  <div class="alert-bar">⚠ Satisfação caiu em todos os canais: Geral 76,5% (meta 90%), WhatsApp 76,6% (meta 90%), IA 64,1% (meta 85%). Causa identificável — monitorar recuperação em julho.</div>
  <div class="grid grid-4">
    <div class="card kpi">
      <div class="label">Satisfação Geral (Jun)</div>
      <div class="value">76,5%</div>
      <div class="delta down">▼ -4,9 p.p. vs mai (81,4%)</div>
      <span class="meta-badge meta-miss">● Meta: 90% — gap: -13,5 p.p.</span>
    </div>
    <div class="card kpi">
      <div class="label">Csat Telefonia (Jun)</div>
      <div class="value">89,3%</div>
      <div class="delta down">▼ vs 92,2% mai</div>
      <span class="meta-badge meta-miss">● Meta: 92% — acum. 90,0%</span>
    </div>
    <div class="card kpi">
      <div class="label">Satisfação WhatsApp (Jun)</div>
      <div class="value">76,6%</div>
      <div class="delta down">▼ -10,4 p.p. vs mai</div>
      <span class="meta-badge meta-miss">● Meta: 90%</span>
    </div>
    <div class="card kpi">
      <div class="label">Satisfação IA (Jun)</div>
      <div class="value">64,1%</div>
      <div class="delta down">▼ -17,5 p.p. vs mai</div>
      <span class="meta-badge meta-miss">● Meta: 85% — investigar</span>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Satisfação Geral — 2025 vs 2026 + Meta</div>
      <div class="chart-box"><canvas id="chart-satisfacao-yoy"></canvas></div>
    </div>
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Csat Telefonia — 2025 vs 2026 + Meta</div>
      <div class="chart-box"><canvas id="chart-csat-tel-yoy"></canvas></div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>NPS por Linha — Jun/2026 vs Metas</div>
      <div class="chart-box tall"><canvas id="chart-nps"></canvas></div>
    </div>
    <div>
      <div class="read-panel">
        <div class="ptitle"><span class="badge context"><span class="dot"></span>CONTEXTO — CHUTE WHATSAPP→URA</span></div>
        <p>A queda simultânea em todos os canais digitais aponta para uma causa comum: o cliente do WhatsApp esperava resolução digital imediata; o novo fluxo via URA gerou fricção perceptível. A satisfação da IA pode ter um fator adicional: com retenção em 50,96%, a IA passou a reter contatos mais complexos (sinistro, reclamações) — que naturalmente geram notas mais baixas independentemente da qualidade da resposta.</p>
      </div>
      <div class="read-panel">
        <div class="ptitle"><span class="badge good"><span class="dot"></span>NPS — DESTAQUES POSITIVOS</span></div>
        <p><strong>NPS de Atendimento voltou a 80%</strong> (sem dado em maio). <strong>NPS de Sinistro em 100%</strong>. NPS Darwin (23%) segue abaixo da meta de 75% — indicador de percepção de marca que transcende a operação de atendimento. Níveis de Serviço de Canais Digitais (TMPR Wpp: 84% atingindo meta em até 7 min; TTR Wpp: 96,99% em até 30 min).</p>
      </div>
    </div>
  </div>
</section>

<!-- ===== 3. EFICIÊNCIA ===== -->
<section id="eficiencia">
  <div class="section-head">
    <div class="section-tag">Bloco 03 — Capacidade de resposta e absorção de demanda</div>
    <div class="section-title">Eficiência Operacional &amp; Telefonia</div>
    <p class="section-desc">Junho apresenta dois movimentos contrários: NS Geral recuperou e ficou acima da meta pela primeira vez no ano, TME caiu — mas o abandono mais que dobrou e o TMA subiu 43%. A implementação do chute WhatsApp→URA e o início do B4B explicam ambos os lados.</p>
  </div>
  <div class="grid grid-4">
    <div class="card kpi">
      <div class="label">NS Geral Telefonia (Jun)</div>
      <div class="value">84,1%</div>
      <div class="delta up">▲ +12,3 p.p. vs mai — 1º mês acima da meta</div>
      <span class="meta-badge meta-hit">✔ Meta: 80%</span>
    </div>
    <div class="card kpi">
      <div class="label">TME (Jun)</div>
      <div class="value">39s</div>
      <div class="delta up">▼ -20s vs mai (59s)</div>
      <span class="meta-badge meta-hit">✔ Meta: &lt;60s</span>
    </div>
    <div class="card kpi">
      <div class="label">% Abandono (Jun)</div>
      <div class="value">16,2%</div>
      <div class="delta down">▲ vs 8,1% mai — pior do ano</div>
      <span class="meta-badge meta-miss">● Meta: 3% — contexto: chute URA</span>
    </div>
    <div class="card kpi">
      <div class="label">TMA (Jun)</div>
      <div class="value">550s</div>
      <div class="delta down">▲ +167s vs mai (+43%)</div>
      <div class="note">Curva de aprendizado B4B + mix mais complexo</div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Nível de Serviço — Geral / CE / SAC / Ouvidoria + Metas</div>
      <div class="chart-box tall"><canvas id="chart-ns"></canvas></div>
    </div>
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>% Abandono e TME — 2026</div>
      <div class="chart-box tall"><canvas id="chart-tme-abandono"></canvas></div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>NS Canais Digitais — Jun vs Meta</div>
      <div class="chart-box"><canvas id="chart-ns-digital"></canvas></div>
    </div>
    <div>
      <div class="read-panel">
        <div class="ptitle"><span class="badge context"><span class="dot"></span>ABANDONO 16,2% — CONTEXTO ESSENCIAL</span></div>
        <p>O abandono disparou porque clientes que chegam via URA (oriundos do WhatsApp) têm baixa tolerância de espera em fila telefônica — vieram do digital esperando agilidade. Com o aumento de volume na fila, mais abandonos foram inevitáveis neste primeiro mês de fluxo.</p>
        <p>Não deve ser lido como colapso operacional. A leitura correta é: <strong>o fluxo está funcionando do ponto de vista técnico, mas ainda gerando fricção de experiência</strong>. Julho será o primeiro teste limpo após a adaptação inicial do cliente ao novo fluxo.</p>
      </div>
      <div class="read-panel">
        <div class="ptitle"><span class="badge good"><span class="dot"></span>DESTAQUES NS</span></div>
        <p>NS SAC: <strong>97,4%</strong> (meta 90%). NS Ouvidoria: <strong>100%</strong>. % Atendidos em até 60s: <strong>100%</strong> — máximo do ano. TMPR WhatsApp em <strong>2 min</strong> — tendência positiva contínua.</p>
      </div>
    </div>
  </div>
  <div class="card" style="margin-top:16px;">
    <div class="block-title"><span class="accent-bar"></span>Telefonia — Tabela Consolidada 2026 (com metas e faróis)</div>
    <div style="overflow-x:auto;">
    <table>
      <thead><tr><th>Indicador</th><th>Meta</th><th class="num">Jan</th><th class="num">Fev</th><th class="num">Mar</th><th class="num">Abr</th><th class="num">Mai</th><th class="num">Jun</th><th class="num">Consol.</th></tr></thead>
      <tbody>
        <tr><td>Total de ligações</td><td>—</td><td class="num">2.045</td><td class="num">1.954</td><td class="num">2.434</td><td class="num">2.452</td><td class="num">1.954</td><td class="num">2.154</td><td class="num">12.993</td></tr>
        <tr><td>NS Geral</td><td>80%</td><td class="num row-bad">64,0%</td><td class="num row-bad">75,0%</td><td class="num row-warn">79,0%</td><td class="num row-good">80,9%</td><td class="num row-bad">71,8%</td><td class="num row-good">84,1% ✔</td><td class="num">75,8%</td></tr>
        <tr><td>NS CE</td><td>85%</td><td class="num row-bad">59,0%</td><td class="num row-bad">72,0%</td><td class="num row-bad">77,0%</td><td class="num row-bad">78,0%</td><td class="num row-bad">66,0%</td><td class="num row-warn">83,8%</td><td class="num">72,6%</td></tr>
        <tr><td>NS SAC</td><td>90%</td><td class="num row-good">91,0%</td><td class="num row-good">92,0%</td><td class="num row-warn">89,0%</td><td class="num row-good">94,0%</td><td class="num row-good">90,0%</td><td class="num row-good">97,4% ✔</td><td class="num">92,2%</td></tr>
        <tr><td>NS Ouvidoria</td><td>90%</td><td class="num row-warn">83,0%</td><td class="num row-good">91,0%</td><td class="num row-good">91,0%</td><td class="num row-good">100%</td><td class="num row-good">92,0%</td><td class="num row-good">100% ✔</td><td class="num">92,8%</td></tr>
        <tr><td>TME (s)</td><td>&lt;60s</td><td class="num row-bad">83</td><td class="num row-good">50</td><td class="num row-good">43</td><td class="num row-good">38</td><td class="num row-warn">59</td><td class="num row-good">39 ✔</td><td class="num">52</td></tr>
        <tr><td>TMA (s)</td><td>—</td><td class="num">424</td><td class="num">450</td><td class="num">433</td><td class="num">420</td><td class="num row-good">383</td><td class="num row-bad">550</td><td class="num">443</td></tr>
        <tr><td>% Abandono</td><td>3%</td><td class="num row-bad">10,2%</td><td class="num row-bad">6,7%</td><td class="num row-bad">5,9%</td><td class="num row-bad">4,2%</td><td class="num row-bad">8,1%</td><td class="num row-bad">16,2%</td><td class="num row-bad">8,5%</td></tr>
        <tr><td>% Atend. ≤60s</td><td>98%</td><td class="num row-bad">76,0%</td><td class="num row-bad">83,0%</td><td class="num row-bad">86,0%</td><td class="num row-bad">87,0%</td><td class="num row-bad">82,0%</td><td class="num row-good">100% ✔</td><td class="num">85,7%</td></tr>
        <tr><td>Csat</td><td>92%</td><td class="num row-bad">87,3%</td><td class="num row-bad">87,3%</td><td class="num row-warn">90,9%</td><td class="num row-good">92,8%</td><td class="num row-good">92,2%</td><td class="num row-warn">89,3%</td><td class="num">90,0%</td></tr>
      </tbody>
    </table>
    </div>
  </div>
</section>

<!-- ===== 4. TECNOLOGIA & IA ===== -->
<section id="tecnologia">
  <div class="section-head">
    <div class="section-tag">Bloco 04 — O motor de eficiência da operação</div>
    <div class="section-title">Tecnologia &amp; Automação</div>
    <p class="section-desc">Junho marca o resultado mais expressivo do semestre para a IA: retenção de 50,96% — primeira vez acima da meta de 50%. A sustentação do status de sinistro e o novo fluxo URA ampliaram o escopo de resolução autônoma. A queda de satisfação da IA merece investigação de causa raiz.</p>
  </div>
  <div class="alert-bar good">🏆 Retenção Kat.IA atingiu 50,96% em junho — PRIMEIRA VEZ acima da meta de 50% no ano. Marco do semestre.</div>
  <div class="grid grid-4">
    <div class="card kpi">
      <div class="label">Retenção Kat.IA (Jun)</div>
      <div class="value">50,96%</div>
      <div class="delta up">▲ +10,2 p.p. vs mai (40,75%)</div>
      <span class="meta-badge meta-hit">✔ Meta: 50% — 1ª vez atingida no ano</span>
    </div>
    <div class="card kpi">
      <div class="label">Tickets c/ Assist. Automática Copilot (acum.)</div>
      <div class="value">40.899</div>
      <div class="delta up">▲ Jun: 7.732</div>
      <div class="note">vs 1.322 em todo 2025</div>
    </div>
    <div class="card kpi">
      <div class="label">% Tickets Enriquecidos Copilot (Jun)</div>
      <div class="value">74,96%</div>
      <div class="delta up">▲ vs 70,0% mai</div>
      <span class="meta-badge meta-miss">● Meta: 85%</span>
    </div>
    <div class="card kpi">
      <div class="label">Satisfação Kat.IA (Jun)</div>
      <div class="value">64,1%</div>
      <div class="delta down">▼ -17,5 p.p. vs mai</div>
      <span class="meta-badge meta-miss">● Meta: 85% — investigar causa raiz</span>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>% Retenção Kat.IA — 2026 vs Meta (50%)</div>
      <div class="chart-box"><canvas id="chart-retencao-ia"></canvas></div>
    </div>
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Copilot — Tickets com Assistência Automática</div>
      <div class="chart-box"><canvas id="chart-copilot"></canvas></div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="read-panel">
      <div class="ptitle"><span class="badge good"><span class="dot"></span>POR QUE A RETENÇÃO ATINGIU A META EM JUNHO</span></div>
      <p>A combinação de dois fatores explica o salto: (1) <strong>sustentação do status de sinistro + última atualização do processo na IA</strong>, que manteve e ampliou a resolução autônoma de contatos de sinistro; e (2) <strong>integração WhatsApp→URA</strong>, que fez mais contatos passar pela IA antes de chegar ao humano.</p>
      <p>Cada ponto percentual acima de 50% representa ~55–60 contatos/mês que não chegam ao atendente humano — <strong>eficiência operacional direta</strong>. Com base nessa trajetória, meta de 55–60% para o 2º semestre é plausível com expansão de escopo.</p>
    </div>
    <div class="read-panel">
      <div class="ptitle"><span class="badge warn"><span class="dot"></span>SATISFAÇÃO IA — HIPÓTESE E PRÓXIMOS PASSOS</span></div>
      <p>A queda de 17,5 p.p. pode não indicar problema da IA. Hipótese principal: ao reter contatos de sinistro (alta carga emocional), a IA dá respostas tecnicamente corretas em situações onde o cliente espera mais do que informação — o que pressiona a nota de satisfação.</p>
      <p><strong>O que investigar</strong>: (a) qual é o perfil dos contatos retidos em junho vs maio? (b) há aumento de contatos de sinistro e reclamação? Se sim, a queda de satisfação é esperada e não indica degradação da ferramenta.</p>
    </div>
  </div>
</section>

<!-- ===== 5. QUALIDADE ===== -->
<section id="qualidade">
  <div class="section-head">
    <div class="section-tag">Bloco 05 — Consistência e precisão do atendimento</div>
    <div class="section-title">Qualidade (QA)</div>
    <p class="section-desc">Junho confirma a recuperação do QA: score de precisão voltou a 90,87% (acima da meta de 90%), volume de avaliações subiu +43%. O B4B demonstrou capacidade de absorção operacional acima do esperado no primeiro mês.</p>
  </div>
  <div class="alert-bar good">✔ QA Precisão recuperou: 76,84% (mai) → 90,87% (jun). Confirma que a queda de maio era efeito de transição — não problema estrutural.</div>
  <div class="grid grid-4">
    <div class="card kpi">
      <div class="label">Score de Precisão (Jun)</div>
      <div class="value">90,87%</div>
      <div class="delta up">▲ +14,0 p.p. vs mai — recuperação total</div>
      <span class="meta-badge meta-hit">✔ Meta: 90%</span>
    </div>
    <div class="card kpi">
      <div class="label">IQI (Jun)</div>
      <div class="value">89,86%</div>
      <div class="delta down">▼ vs 90,98% mai</div>
      <span class="meta-badge meta-miss">● Meta: 93%</span>
    </div>
    <div class="card kpi">
      <div class="label">Conversas Avaliadas (Jun)</div>
      <div class="value">3.493</div>
      <div class="delta up">▲ +43% vs mai (2.443)</div>
    </div>
    <div class="card kpi">
      <div class="label">Conversas Avaliadas (acum.)</div>
      <div class="value">26.406</div>
      <div class="delta up">▲ vs 8.581 em todo 2025</div>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Score de Precisão e IQI — 2026 vs Metas</div>
      <div class="chart-box tall"><canvas id="chart-qa"></canvas></div>
    </div>
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Volume de Conversas Avaliadas</div>
      <div class="chart-box tall"><canvas id="chart-qa-volume"></canvas></div>
    </div>
  </div>
  <div class="read-panel" style="margin-top:16px;">
    <div class="ptitle"><span class="badge good"><span class="dot"></span>B4B — DESEMPENHO NO PRIMEIRO MÊS</span></div>
    <p>A recuperação do QA de precisão para <strong>90,87%</strong> no primeiro mês completo com o B4B é o sinal mais positivo sobre o novo parceiro. A velocidade de retomada superou a expectativa para um time em onboarding. O IQI (89,86%) ficou 3,1 p.p. abaixo da meta de 93%, mas dentro do padrão esperado para uma equipe em adaptação. O que monitorar: manutenção da precisão acima de 90% e recuperação do IQI para 93%+ nas próximas semanas.</p>
  </div>
</section>

<!-- ===== 6. PESSOAS ===== -->
<section id="pessoas">
  <div class="section-head">
    <div class="section-tag">Bloco 06 — Estrutura e estabilidade do time</div>
    <div class="section-title">Pessoas</div>
    <p class="section-desc">Junho é o primeiro mês com o B4B operando integralmente (8 agentes), substituindo a Plurismidia. Time total de 14 agentes (6 Darwin + 8 B4B). Zero faltas e zero turnover — base estável para a curva de maturidade do novo parceiro.</p>
  </div>
  <div class="grid grid-4">
    <div class="card kpi">
      <div class="label">Total de Agentes (Jun)</div>
      <div class="value">14</div>
      <div class="delta up">▲ vs 13 mai</div>
      <div class="note">6 Darwin + 8 B4B (novo parceiro)</div>
    </div>
    <div class="card kpi">
      <div class="label">Agentes Darwin (Jun)</div>
      <div class="value">6</div>
      <div class="delta flat">≈ estável ao longo do semestre</div>
    </div>
    <div class="card kpi">
      <div class="label">Agentes B4B (1º mês)</div>
      <div class="value">8</div>
      <div class="delta up">Substitui Plurismidia (média: 7,4/mês)</div>
    </div>
    <div class="card kpi">
      <div class="label">% Absenteísmo (Jun)</div>
      <div class="value">0%</div>
      <div class="delta up">Zero faltas em junho</div>
      <span class="meta-badge meta-hit">✔ Meta: ≤3%</span>
    </div>
  </div>
  <div class="grid grid-2" style="margin-top:16px;">
    <div class="card">
      <div class="block-title"><span class="accent-bar"></span>Composição da Equipe — 2026</div>
      <div class="chart-box tall"><canvas id="chart-pessoas"></canvas></div>
    </div>
    <div class="read-panel" style="display:flex;flex-direction:column;justify-content:center;">
      <div class="ptitle"><span class="badge context"><span class="dot"></span>LEITURA — PRIMEIRO MÊS B4B</span></div>
      <p>O TMA de 550s (+43% vs maio) é o principal termômetro da curva de aprendizado do B4B. Espera-se queda progressiva nas próximas 4–8 semanas, conforme o time ganha familiaridade com processos, scripts e ferramentas (Copilot e Kat.IA).</p>
      <p>Zero absenteísmo e zero turnover indicam <strong>engajamento e estabilidade do novo time desde o início</strong>. O QA já recuperado (90,87%) reforça que a capacidade técnica do B4B está dentro do esperado — acima, na verdade.</p>
      <p><strong>Termômetro para julho:</strong> TMA abaixo de 450s confirmará que a curva de aprendizado está no ritmo adequado.</p>
    </div>
  </div>
</section>

<!-- ===== 7. CONTEXTO ===== -->
<section id="contexto">
  <div class="section-head">
    <div class="section-tag">Bloco 07 — O que mudou em junho e o que isso explica</div>
    <div class="section-title">Contexto e Transformação — Junho/2026</div>
    <p class="section-desc">Junho concentrou três mudanças estruturais simultâneas. Esta seção conecta cada mudança aos indicadores observados, com leitura executiva de impacto esperado vs observado.</p>
  </div>
  <div class="card">
    <div class="timeline">
      <div class="tl-item">
        <div class="tl-date">JUNHO/2026 — NOVO FLUXO</div>
        <div class="tl-title">Implementação do "chute" WhatsApp → URA (A24h, Vidros, Sinistro)</div>
        <div class="tl-body">
          <p><strong>Impactos positivos observados:</strong> mais contatos passam pela IA antes do humano (retenção dispara), NS Geral recupera, TME cai, % atendidos em até 60s atinge 100%.</p>
          <p><strong>Impactos negativos observados:</strong> abandono de 16,2% (clientes do WhatsApp com baixa tolerância de espera), satisfação cai em todos os canais digitais, e-mail salta +149% (possíveis notificações automáticas do novo fluxo).</p>
          <p><strong>Leitura executiva:</strong> o chute foi bem executado tecnicamente — o desafio agora é o ajuste de experiência. Julho é o primeiro mês de teste limpo após adaptação inicial do cliente ao novo fluxo.</p>
        </div>
      </div>
      <div class="tl-item">
        <div class="tl-date">JUNHO/2026 — SUSTENTAÇÃO</div>
        <div class="tl-title">Status de sinistro + última atualização do processo na IA</div>
        <div class="tl-body">
          <p><strong>Impacto consolidado:</strong> retenção IA em 50,96% — meta de 50% superada pela primeira vez. Salto de +10,2 p.p. vs maio, o maior do semestre.</p>
          <p><strong>Hipótese sobre satisfação da IA:</strong> ao reter contatos de sinistro (alta carga emocional), a IA pode gerar respostas corretas para situações percebidas como insuficientes — o que pressiona a nota. Investigar perfil dos contatos retidos em junho.</p>
          <p><strong>Próximo passo:</strong> expansão de escopo — CR (carro reserva) ou abertura de novos serviços — para buscar retenção de 55–60%.</p>
        </div>
      </div>
      <div class="tl-item">
        <div class="tl-date">JUNHO/2026 — 1º MÊS COMPLETO</div>
        <div class="tl-title">BPO B4B — Primeiro mês de operação integral</div>
        <div class="tl-body">
          <p><strong>Sinais positivos:</strong> QA de precisão recuperado para 90,87% (meta atingida), zero absenteísmo, zero turnover — desempenho acima do esperado para onboarding.</p>
          <p><strong>Ponto de atenção:</strong> TMA de 550s (+43% vs maio) reflete curva de aprendizado esperada. O time ainda está ganhando familiaridade com processos, casos atípicos e uso ativo do Copilot.</p>
          <p><strong>Termômetro para julho:</strong> TMA abaixo de 450s confirmará que a curva está sendo vencida no ritmo adequado. Manutenção do QA acima de 90% confirmará consistência.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="read-panel" style="margin-top:16px;">
    <div class="ptitle"><span class="badge info"><span class="dot"></span>LEITURA EXECUTIVA CONSOLIDADA</span></div>
    <p>Junho entregou <strong>ganhos estruturais expressivos</strong> (retenção IA na meta, QA recuperado, NS de telefonia acima da meta pela primeira vez no ano) e <strong>pressão transitória na satisfação</strong> (causa identificável: novo fluxo de URA). O B4B mostrou capacidade operacional acima do esperado. A carteira Auto em queda é o único sinal que exige resposta fora da operação de atendimento.</p>
  </div>
</section>

<!-- ===== 8. SWOT ===== -->
<section id="swot">
  <div class="section-head">
    <div class="section-tag">Bloco 08 — Leitura estratégica da operação</div>
    <div class="section-title">Análise SWOT — Atualizada Jun/2026</div>
    <p class="section-desc">Síntese estratégica conectando os resultados de junho ao contexto de transformação do semestre.</p>
  </div>
  <div class="swot-grid">
    <div class="swot-card swot-s">
      <h3>Forças (Strengths)</h3>
      <ul>
        <li><strong>Retenção IA acima da meta (50,96%)</strong> pela primeira vez — resultado de investimento contínuo em funcionalidades.</li>
        <li><strong>QA de Precisão recuperado (90,87%)</strong> no primeiro mês com o B4B — absorção rápida do parceiro.</li>
        <li><strong>NS Telefonia acima da meta</strong> (Geral 84,1%, SAC 97,4%, Ouvidoria 100%) pela primeira vez no ano.</li>
        <li><strong>Maturidade tecnológica consolidada</strong>: Copilot estável, IA com escopo crescente mês a mês.</li>
        <li><strong>Zero absenteísmo e zero turnover</strong> em junho com 14 agentes em transição.</li>
      </ul>
    </div>
    <div class="swot-card swot-w">
      <h3>Fraquezas (Weaknesses)</h3>
      <ul>
        <li><strong>Satisfação generalizada em queda</strong>: Geral (76,5%), WhatsApp (76,6%), IA (64,1%) — todas abaixo das metas.</li>
        <li><strong>Abandono de telefonia em 16,2%</strong> (meta 3%) — exposição à percepção de inacessibilidade.</li>
        <li><strong>TMA em 550s</strong> — curva de aprendizado do B4B ainda em curso.</li>
        <li><strong>NPS Darwin cronicamente abaixo da meta</strong> (23%, meta 75%) — problema estrutural de percepção de marca.</li>
        <li><strong>Copilot enriquecimento abaixo da meta</strong> (74,96% vs 85%) — potencial subutilizado pelo novo time.</li>
      </ul>
    </div>
    <div class="swot-card swot-o">
      <h3>Oportunidades (Opportunities)</h3>
      <ul>
        <li><strong>Estabilização do fluxo URA/WhatsApp</strong>: quando o cliente internalizar o novo fluxo, abandono deve cair e satisfação deve se recuperar.</li>
        <li><strong>Expansão do escopo da IA</strong>: com retenção acima de 50%, há base para ampliar para 55–60% — CR, novos serviços, etc.</li>
        <li><strong>Copilot como acelerador do B4B</strong>: treinamento focado pode elevar enriquecimento de 75% para 85% e reduzir TMA.</li>
        <li><strong>Curva de maturidade do B4B</strong>: ganho de produtividade e qualidade simultâneos esperados para jul/ago.</li>
        <li><strong>POC de ferramenta de NPS</strong>: qualificação da coleta pode revelar que satisfação da IA é impactada pelo perfil de contatos, não pela ferramenta.</li>
      </ul>
    </div>
    <div class="swot-card swot-t">
      <h3>Riscos (Threats)</h3>
      <ul>
        <li><strong>Queda de satisfação persistente</strong>: se não reverter até agosto, pode indicar problema estrutural com risco de impacto em churn.</li>
        <li><strong>Abandono de telefonia elevado</strong>: clientes que abandonam podem buscar canais alternativos (redes sociais, ouvidoria regulatória).</li>
        <li><strong>Carteira Auto em queda (-13,5%)</strong>: se confirmada como perda real, o modelo pode estar superdimensionado para demanda futura.</li>
        <li><strong>Retenção IA x satisfação IA</strong>: crescer retenção às custas da satisfação não é sustentável — equação a resolver.</li>
        <li><strong>Acúmulo de mudanças simultâneas</strong>: dificulta diagnóstico preciso de causas — risco de decisões baseadas em correlação.</li>
      </ul>
    </div>
  </div>
</section>

<!-- ===== 9. DIRETORIA ===== -->
<section id="diretoria">
  <div class="section-head">
    <div class="section-tag">Bloco 09 — Síntese para apresentação executiva</div>
    <div class="section-title">Mensagens-Chave &amp; Recomendações</div>
    <p class="section-desc">Síntese das mensagens que devem acompanhar o dashboard em apresentação à diretoria e recomendações de estruturação da leitura.</p>
  </div>
  <div class="msg-grid">
    <div class="msg-card">
      <span class="mtag" style="color:var(--blue);">O que a diretoria precisa saber</span>
      <ul>
        <li>Junho foi o mês de maior transformação do semestre: <strong>três mudanças estruturais simultâneas</strong> (URA, IA, BPO novo).</li>
        <li>A operação entregou <strong>ganhos expressivos de eficiência e qualidade</strong>, mas a satisfação sentiu o impacto do novo fluxo.</li>
        <li>A <strong>queda da carteira Auto (-13,5%)</strong> exige resposta da área comercial.</li>
      </ul>
    </div>
    <div class="msg-card">
      <span class="mtag" style="color:var(--good);">O que merece reconhecimento</span>
      <ul>
        <li><strong>Retenção IA em 50,96%</strong>: meta histórica atingida pela primeira vez.</li>
        <li><strong>QA recuperado no primeiro mês do B4B</strong>: novo parceiro com capacidade acima do esperado.</li>
        <li><strong>NS Geral acima da meta pela primeira vez no ano</strong> (84,1%).</li>
        <li><strong>Zero absenteísmo</strong> com 14 agentes em plena transição operacional.</li>
      </ul>
    </div>
    <div class="msg-card">
      <span class="mtag" style="color:var(--warn);">O que exige monitoramento (30–60 dias)</span>
      <ul>
        <li><strong>Recuperação da satisfação</strong> (geral, WhatsApp e IA) — termômetro do fluxo URA.</li>
        <li><strong>Queda do abandono</strong> como confirmação de absorção do novo fluxo pelo cliente.</li>
        <li><strong>TMA do B4B</strong> abaixo de 450s em julho.</li>
        <li><strong>Esclarecimento sobre carteira Auto</strong>.</li>
        <li><strong>Causa raiz da queda de satisfação da IA</strong>.</li>
      </ul>
    </div>
    <div class="msg-card">
      <span class="mtag" style="color:var(--purple);">O que sinaliza potencial de ganho futuro</span>
      <ul>
        <li><strong>Retenção IA acima de 50%</strong> abre espaço para meta de 55–60% com expansão de escopo.</li>
        <li><strong>Fluxo URA integrado ao WhatsApp</strong>, quando estabilizado, reduz custo por contato.</li>
        <li><strong>B4B com boa absorção inicial</strong>: potencial de melhora acelerada de produtividade.</li>
        <li><strong>Copilot com potencial de expansão</strong>: treinamento B4B pode elevar enriquecimento para 85%+.</li>
      </ul>
    </div>
  </div>
  <div class="card" style="margin-top:24px;">
    <div class="block-title"><span class="accent-bar"></span>Recomendações para a Apresentação</div>
    <p style="font-size:13.5px;color:var(--text);font-weight:700;margin-bottom:8px;">Indicadores de primeira página</p>
    <div class="chip-list">
      <span class="chip">🏆 Retenção IA — 50,96% (marco)</span>
      <span class="chip">⚠ Satisfação Geral — 76,5% vs 90%</span>
      <span class="chip">✔ NS Geral — 84,1% (acima da meta)</span>
      <span class="chip">⚠ % Abandono — 16,2% (contexto URA)</span>
      <span class="chip">✔ QA Precisão — 90,87% (recuperado)</span>
    </div>
    <p style="font-size:13.5px;color:var(--text);font-weight:700;margin:18px 0 8px;">Indicadores de apoio</p>
    <div class="chip-list">
      <span class="chip">TME / TMA / Csat</span>
      <span class="chip">Copilot — enriquecimento</span>
      <span class="chip">NPS por linha</span>
      <span class="chip">Estrutura de pessoas</span>
      <span class="chip">Carteira Auto — alerta</span>
    </div>
    <div class="read-panel" style="margin-top:18px;">
      <div class="ptitle"><span class="badge warn"><span class="dot"></span>COMPARAÇÕES E LINGUAGEM A USAR COM CUIDADO</span></div>
      <p>Retenção IA acima de 50% pode ser mencionada como <strong>"potencialmente competitiva para o segmento"</strong> — inferência qualitativa, sem benchmark confirmado. Abandono (16,2%) e queda de satisfação devem <strong>sempre vir com o contexto da implementação do chute URA</strong> — nunca apresentados de forma isolada. Carteira Auto deve ser destacada como ponto de <strong>investigação</strong>, não como fato consolidado de perda.</p>
    </div>
  </div>
  <div class="footnote">
    <span>ⓘ</span>
    <span>Leitura de mercado: retenção por IA acima de 50% e Csat de telefonia acumulado em 90% são, em termos gerais, <strong>potencialmente acima da média</strong> para operações de assistência veicular/seguros sem IA conversacional madura. Inferência qualitativa — sem benchmark externo validado.</span>
  </div>
</section>
`;
